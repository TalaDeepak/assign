import "./App.css";
import MuiSwitch from "./components/MuiSwitch";

function App() {
  return (
    <div className="main">
      <MuiSwitch />
    </div>
  );
}

export default App;
