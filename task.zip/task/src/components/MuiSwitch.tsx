import { Box, FormControlLabel, Switch, Typography } from "@mui/material";
import { useState, ChangeEvent } from "react";
import Settings from "./Settings";

const MuiSwitch: React.FC = () => {
  const [checked, setChecked] = useState<boolean>(true);

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setChecked(e.target.checked);
  };

  return (
    <Box className="container">
      <FormControlLabel
        label={
          <div className="center">
            <Typography
              sx={{
                fontSize: "30px",
                fontWeight: "700",
                color: "#4e4d4d",
              }}
              variant="h5"
            >
              Setup Auto Top-up
            </Typography>
            <Switch
              color="success"
              checked={checked}
              onChange={handleChange}
              size="medium"
            />
          </div>
        }
        sx={{
          display: "flex",
          paddingBottom: "20px",
        }}
        control={<></>}
      />
      <Typography variant="h6" className="light">
        {checked
          ? "Once the credit goes below a minimum threshold 50, we will auto-purchase 1200 credits and add them to your account"
          : "Once the credit goes below the threshold value, credits can be auto purchased. Setup auto top-up to enjoy uninterrupted services. You can disable this anytime to stop auto top-up"}
      </Typography>
      {checked && <Settings />}
    </Box>
  );
};

export default MuiSwitch;
