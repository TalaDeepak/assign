import { Button, Slider } from "@mui/material";
import { useState, MouseEvent } from "react";

interface Mark {
  value: number;
  label: string;
}

const Settings: React.FC = () => {
  const [slider, setSlider] = useState<number>(10);
  const marks: Mark[] = [
    {
      value: 5,
      label: "500 credits",
    },
    {
      value: 10,
      label: "1200 credits",
    },
    {
      value: 15,
      label: "1700 credits",
    },
    {
      value: 20,
      label: "2500 credits",
    },
    {
      value: 25,
      label: "3900 credits",
    },
    {
      value: 30,
      label: "5000 credits",
    },
  ];

  const handleButtonClick = (e: MouseEvent<HTMLButtonElement>) => {
    const val = marks.filter((item) => item.value === slider);
    if (val.length === 0) {
      alert(`Select the specified credits ⚠️ invalid selection`);
      return;
    }
    alert(`You have selected ${val[0].label}`);
    console.log(val[0].label);
  };

  const handleSliderChange = (e: Event, value: number | number[]) => {
    setSlider(value as number);
  };

  return (
    <div>
      <div>
        <Slider
          sx={{
            display: "inline-block",
            paddingLeft: "10px",
            alignItems: "start",
            marginBottom: "50px",
            marginTop: "50px",
            color: "rgb(104, 3, 177)",
          }}
          defaultValue={10}
          max={30}
          min={5}
          marks={marks}
          value={slider}
          valueLabelDisplay="auto"
          onChange={handleSliderChange}
        />
      </div>
      <Button
        className="btn"
        sx={{
          backgroundColor: "rgb(104, 3, 177)",
          fontSize: "17px",
          display: "flex",
          alignItems: "start",
          borderRadius: "8px",
        }}
        variant="contained"
        onClick={handleButtonClick}
      >
        Confirm auto–purchase
      </Button>
    </div>
  );
};

export default Settings;
